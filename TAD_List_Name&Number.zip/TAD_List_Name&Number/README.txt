Code by Eduardo Costa
IG:edf_costa

Case 1:
	Verifica se a lista está vazia.
Case 2:
	Solicita nome e numero para inserir no inicio da lista encadeada.
Case 3:
	Solicita nome, numero e posição (0 a (x-1) ) para inserir em uma posição específica.
Case 4:
	olicita nome e numero para inserir no fim da lista encadeada.
Case 5:
	Remove primeiro elemento da lista
Case 6:
	Solicita uma posição (1 a x) e elimina.
Case 7:
	Imprime e retorna o tamanho da lista.
Case 8:
	Encontra e elimina o maior elemento da lista.
Case 9:
	Imprime a lista, nessa há duas opções: 1 imprimirá um elemento específico (de 0 a x) 
		e 2 imprimirá a lista completa.
Case 10:
	bubblesort ordena em ordem crescente para impressão.

Case 11:
	finaliza o menu e limpa a lista.